package in.geetha.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.geetha.model.Flight;

public interface FlightRepository extends JpaRepository <Flight , Long>{

}
