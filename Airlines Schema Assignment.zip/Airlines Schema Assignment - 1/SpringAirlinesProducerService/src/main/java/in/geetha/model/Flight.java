package in.geetha.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Flight_Details")
@Data
public class Flight {
	
	public Flight() {
		super();
	}


	

	public Flight(Long id, String name, String source, String destination, String fare) {
		super();
		this.id = id;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.fare = fare;
	}




	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //for mysql
	@Column(name="Flight_id")
	private Long id;
	
	
	@Column(name="Flight_name")
	private String name;
	
	@Column(name="source")
	private String source;
	
	
	
	@Column(name="dest")
	private String destination;
	
	@Column(name="Flight_fare")
	private String fare;
	
	
	
	



}
