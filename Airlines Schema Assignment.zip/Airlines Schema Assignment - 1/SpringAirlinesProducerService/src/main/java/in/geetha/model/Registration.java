package in.geetha.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Registration_Details")
@Data
public class Registration {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //for mysql
	@Column(name="Reg_id")
	private Long regid;
	
	
	@Column(name="name")
	private String name;
	
	@Column(name="mobile_no")
	private String mobile;
	
	
	@Column(name="email")
	private String email;
	

	@Column(name="age")
	private String age;
	
	
	@Column(name="address")
	private String address;
	
	
	
	
	
}
