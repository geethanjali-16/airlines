package in.geetha.RestController;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.geetha.Repository.FlightRepository;
import in.geetha.model.Flight;

@RestController
@RequestMapping("/flight")
public class FlightRestController {
	
	private FlightRepository repo;

	public FlightRestController(FlightRepository repo) {
		super();
		this.repo = repo;
	}
	
	@PostMapping("/new")
	public String saveFlight(@RequestBody Flight f) {
		f=repo.save(f);
		
		return "Flight with id "+f.getId()+"  saved";
		
	}
	
	@GetMapping("/all")
	public List<Flight> getAll(){
		List l = (List) repo.findAll();
		
		return l;
		
	}
	
	@GetMapping("/{id}")
	public Flight getById(@PathVariable Long id) {
		
		
		return repo.findById(id).get();
		
	}
	
	
	


}
