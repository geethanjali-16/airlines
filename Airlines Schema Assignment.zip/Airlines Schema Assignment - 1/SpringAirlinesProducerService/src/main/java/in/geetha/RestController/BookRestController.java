package in.geetha.RestController;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.geetha.Repository.FlightRepository;
import in.geetha.Repository.RegistrationRepository;
import in.geetha.model.Flight;
import in.geetha.model.Registration;
@RestController
@RequestMapping("/book")
public class BookRestController {
	@Autowired
	private RegistrationRepository regrepo;
	@Autowired
	private FlightRepository frepo;
	
	@GetMapping("/{regid},{id}")
	public String bookFlight(@PathVariable Long regid,@PathVariable Long id){
		
		boolean r = regrepo.existsById(regid);
		boolean fb = frepo.existsById(id);
//		Optional<Registration>c=regrepo.findById(regid);
//	Registration c1=c.get();
//	Optional<Flight> f=frepo.findById(id);
//	Flight fl=f.get();
		
	ResponseEntity<?> resp = null;
//	
	if(r && fb) {
	 return"You are able to book ticket";
	}else {
		return"You are not able to book ticket";
	}

}
	}
