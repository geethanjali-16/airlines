package in.geetha.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.geetha.model.Registration;

public interface RegistrationRepository extends JpaRepository <Registration , Long>{

}
