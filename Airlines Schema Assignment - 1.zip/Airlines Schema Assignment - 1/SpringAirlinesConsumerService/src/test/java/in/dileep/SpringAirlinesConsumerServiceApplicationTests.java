package in.dileep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAirlinesConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
