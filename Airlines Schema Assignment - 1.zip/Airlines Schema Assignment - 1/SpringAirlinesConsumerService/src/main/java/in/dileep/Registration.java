package in.dileep;



import lombok.Data;

@Data
public class Registration {

	
	private Long regid;
	
	
	private String name;
	
	private String mobile;
	
	
	private String email;
	

	private String age;
	
	
	private String address;
	
	
	
	
	
}
