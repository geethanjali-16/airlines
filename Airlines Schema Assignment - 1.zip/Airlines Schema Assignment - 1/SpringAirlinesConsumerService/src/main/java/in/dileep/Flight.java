package in.dileep;



import lombok.Data;


@Data
public class Flight {
	
	public Flight() {
		super();
	}


	

	public Flight(Long id, String name, String source, String destination, String fare) {
		super();
		this.id = id;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.fare = fare;
	}




	private Long id;
	
	
	private String name;
	
	private String source;
	
	
	
	private String destination;
	
	private String fare;
	
	
	
	



}
