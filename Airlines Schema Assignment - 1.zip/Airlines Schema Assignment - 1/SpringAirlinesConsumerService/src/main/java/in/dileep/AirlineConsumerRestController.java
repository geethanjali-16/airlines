package in.dileep;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bookFlight")
public class AirlineConsumerRestController {
	
	
	private AirlineRestConsumer consumer;
	public AirlineConsumerRestController(AirlineRestConsumer consumer) {
		super();
		this.consumer = consumer;
	}
	
	@GetMapping("/{regid},{id}")
	public String bookFlights(@PathVariable Long regid , @PathVariable Long id) {
		
		return consumer.bookFlight(regid, id);
		
		
	}
	
	

}
