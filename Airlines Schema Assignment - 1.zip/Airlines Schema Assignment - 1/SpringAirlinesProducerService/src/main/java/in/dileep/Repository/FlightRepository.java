package in.dileep.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.dileep.model.Flight;

public interface FlightRepository extends JpaRepository <Flight , Long>{

}
