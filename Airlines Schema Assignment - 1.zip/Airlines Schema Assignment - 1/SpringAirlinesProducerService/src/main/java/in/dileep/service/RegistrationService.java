package in.dileep.service;

import java.util.List;

import in.dileep.model.Registration;


public interface RegistrationService {
	
public Long savePassenger(Registration p);
	
	public Registration getPassengerById(Long id);
	
	public List<Registration> getAllPassengers();
	

}
