package in.dileep.RestController;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.dileep.model.Registration;
import in.dileep.service.RegistrationService;

@RestController
@RequestMapping("/passenger")
public class RegistrationRestController {

	private RegistrationService service;

	public RegistrationRestController(RegistrationService service) {
		super();
		this.service = service;
	}
	
	@PostMapping("/new")
	public String register(@RequestBody Registration p) {
		Long id = service.savePassenger(p);
		
		return "Passenger with id "+id+"  registered";
		
	}
	
	@GetMapping("/all")
	public List<Registration> getAll(){
		List l = service.getAllPassengers();
		
		return l;
		
	}
	
	@GetMapping("/{id}")
	public Registration getById(@PathVariable Long id) {
		
		
		return service.getPassengerById(id);
		
	}
	
	
	
}
