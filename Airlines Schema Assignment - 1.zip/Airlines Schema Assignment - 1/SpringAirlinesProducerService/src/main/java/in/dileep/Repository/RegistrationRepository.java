package in.dileep.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.dileep.model.Registration;

public interface RegistrationRepository extends JpaRepository <Registration , Long>{

}
